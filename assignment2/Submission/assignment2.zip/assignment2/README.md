# VIP

To run scripts for given assignment

`cd ./assignment<X>`

and then run

`python main.py`
